<?php
defined('_JEXEC') or die;

function modChrome_footer($module, &$params, &$attribs){
    if(!$module->content)
        return;
?>
    <div class="module">
        <?php if($module->name == 'custom'):?>
            <?=$module->content?>
        <?php else:
            preg_match_all('#<a[^<]*</a>#i', $module->content, $matches);?>
            <h1><?=$module->title?></h1>
            <ul>
                <?php foreach($matches[0] as $a):?>
                    <li><?=$a?></li>
                <?php endforeach;?>
            </ul>
        <?php endif;?>
    </div>
<?php
}


function modChrome_rightbanner($module, &$params, &$attribs)
{
?>
        <div style="position:absolute; right:0px; top:100px;">
            <?=$module->content?>
        </div>
<?php 
}

function modChrome_usercontroll($module, &$params, &$attribs)
{
    if(!$module->content)
        return;
    preg_match_all('#<a[^>]*>.*?</a>#i', $module->content, $matches);
?>
    <div id="headerSection">
        <div class="btn_login"><?=$matches[0][0]?></div>
        <ul class="clearfix options">
            <li class="sec_language_left marginLeft10"><a href="#">DE</a></li>
            <li class="sec_language_right active"><a href="#">EN</a></li>
        </ul>
    </div>
<?php 
}

function modChrome_leftmenu($module, &$params, &$attribs)
{
    if(!$module->content)
        return;
    preg_match_all('#<a[^>]*>.*?</a>#i', $module->content, $matches);
?>
    <div class="floatLeftNav">
        <div class="md_head"></div>
        <ul class="md_body">
            <li><a href="#">News</a></li>
            <li><a href="#">Uber uns</a></li>
            <li>
                <a href="#">Medien</a>
                <ul>
                    <li><a href="#">Screenshots</a></li>
                    <li><a href="#">Logo</a></li>
                </ul>
            </li>
            <li><a href="#">Karriere</a></li>
        </ul>
        <div class="md_bottom"></div>
    </div>
<?php 
}

function modChrome_partner($module, &$params, &$attribs)
{
    if(!$module->content)
        return;
    preg_match_all('#<a([^>]*)>(<img[^>]*>)?(.*?)</a>#i', $module->content, $matches);
    list($o, $attr, $img, $text) = $matches;
    echo "<div>";
    foreach($o as $k=>$v){
        echo "<a{$attr[$k]}>". ($img[$k] ? $img[$k] : $text[$k]) ."</a>";
    }
    echo "</div>";
}

/**
 * separate the navigation to nav1, nav2 and nav3
 *
 *
 */
function modChrome_navigation($module, &$params, &$attribs)
{
    if(!$module->content)
        return;

    preg_match_all('#<li.*?class="(.*?)".*?>(<a([^>]*)>(<img[^>]*>)?(.*?)</a>)#i', $module->content, $matches);
    list($x, $act, $o, $attr, $img, $text) = $matches;
    switch($module->position):
        case 'nav1':
?>
            <div class="left">
                <span class="left sec_right"></span>
                <?php if(isset($o[0])){?>
                    <span class="section">
                        <span class="sec_left"></span>
                        <a class="section section_side" <?=$attr[0]?>>
                            <?=$img[0]?$img[0]:$text[0]?>
                        </a>
                        <span class="left sec_right"></span>
                    </span>
                <?php }?>
                <span class="sec_left"></span>
                <?php unset($act[0], $o[0], $img[0], $text[0], $attr[0]);
                foreach($o as $k=>$v){?>
                    <span class="section <?=$act[$k]?>">
                        <a class="section_side" <?=$attr[$k]?>>
                            <div class="inner_nav"><?=$img[$k]?$img[$k]:$text[$k]?></div>
                        </a>
                        <div class="interator"></div>
                    </span>
                <?php }?>
                <span class="sec_right"></span>
            </div>
        <?php break;

        case 'nav3':
        ?>
            <div class="right">
                <span class="sec_left"></span>
                <span class="right sec_left"></span>
                <span class="sec_right"></span>
                <?php
                foreach($o as $k=>$v){?>
                    <span class="section <?=$act[$k]?>">
                        <a class="section_side" <?=$attr[$k]?>>
                            <div class="inner_nav"><?=$img[$k]?$img[$k]:$text[$k]?></div>
                        </a>
                        <div class="interator"></div>
                    </span>
                <?php }?>
            </div>
        <?php break;

        case 'nav2':
        ?>
            <div class="center">
                <div class="section balance  <?=$href[0]!='/'&&strpos($_SERVER['SCRIPT_NAME'],$href[0])!==false?'active':''?>">
                    <a href="<?=$href[0]?>">
                        <div class="clearfix">
                            <span class="sec_left"></span>
                            <span class="left body">
                                <div class="icon layout"></div>
                                <?=$text[0]?>
                            </span>
                            <span class="sec_right"></span>
                        </div>
                    </a>
                    <div class="interator"></div>
                </div>
                <div class="section healthcheck <?=$href[1]!='/'&&strpos($_SERVER['SCRIPT_NAME'], $href[1])!==false?'active':''?>">
                    <a href="<?=$href[0]?>">
                        <div class="clearfix">
                            <span class="sec_left"></span>
                            <span class="left body">
                                <div class="icon layout"></div>
                                <?=$text[1]?>
                            </span>
                            <span class="sec_right"></span>
                        </div>
                    </a>
                    <div class="interator"></div>
                </div>
            </div>
<?php 
            break;
    endswitch;
}
