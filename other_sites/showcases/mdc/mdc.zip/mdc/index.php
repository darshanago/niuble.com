<?php $is_home = (bool)JFactory::getDbo()
            ->setQuery('SELECT id FROM #__menu where home=1 and id='.JRequest::getVar('Itemid')) 
            ->loadObject();
    if(JRequest::getVar('view') == 'category'){
        $content = JFactory::getDbo()
                    ->setQuery('SELECT id,alias FROM #__content where catid='.JRequest::getVar('id').' and state=1 order by ordering desc limit 1') 
                    ->loadObject();
        $url = JRequest::getUri().DS.$content->id.'-'.$content->alias;
        Header("HTTP/1.1 303 See Other");
        Header("Location: ".$url);  
        exit;  
    }
            ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>" >
	<head>
		<jdoc:include type="head" />
        <link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template; ?>/css/common.css" type="text/css" media="screen" />
        <link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template; ?>/css/layout.css" type="text/css" media="screen" />
        <link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template; ?>/css/home.css" type="text/css" media="screen" />
        <script type="text/javascript" src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template; ?>/javascript/jquery-1.4.4.js"></script>
        <script type="text/javascript" src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template; ?>/javascript/main.js"></script>
    </head>

    <body>
        <div id="header">
            <div id="logoLayout">
                <div class="layout clearfix">
                    <div id="logo">
                        <a href="#"><img width="225px" src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template; ?>/images/logos/logo.png"/></a>
                    </div>
                    <jdoc:include type="modules" name="usercontroll" style="usercontroll" />
                </div>
            </div>
            <div id="navigation" class="clearfix">
                <div class="layout clearfix">
                    <jdoc:include type="modules" name="nav1" style="navigation" />
                    <jdoc:include type="modules" name="nav2" style="navigation" />
                    <jdoc:include type="modules" name="nav3" style="navigation" />
                </div>
            </div>
        </div>
        <div id="page_title">
            <div class="layout">
            </div>
        </div>

        <!-- Content Begin -->
        <?php if($is_home):?>
            <div id="contentLayout">
                <div class="verLayout">
                    <div class="layout clearfix">
                        <div class="feature">
                            <jdoc:include type="modules" name="video" style="" />
                        </div>
                        <div class="rightcloumn">
                            <jdoc:include type="modules" name="content1" style="" />
                        </div>
                    </div>
                </div>
                <div class="verLayout lower">
                    <div class="layout clearfix">
                        <jdoc:include type="modules" name="box1" style="" />
                        <jdoc:include type="modules" name="box2" style="" />
                        <jdoc:include type="modules" name="box3" style="" />
                        <jdoc:include type="modules" name="boxnews" style="" />
                    </div>
                    <div class="layout clearfix">
                        <div class="chr_title">Unsere Partner</div>
                        <jdoc:include type="modules" name="partner" style="partner" />
                    </div>
                </div>
            </div>
        <?php else: ?>
            
            <div id="contentLayout" class="separator">
                <div class="layout clearfix">
                    <div class="leftLayout240 marginTop10 marginBottom20">
                        <jdoc:include type="modules" name="leftmenu" style="leftmenu" />
                    </div>
                    <div class="leftLayout500 marginTop10 textBody">
                        <jdoc:include type="component" />
                    </div>
                </div>
            </div>
        <?php endif;?>
        <!-- Content End -->

        <div id="footer">
            <div class="layout">
                <jdoc:include type="modules" name="footer1" style="footer" />
                <jdoc:include type="modules" name="footer2" style="footer" />
                <jdoc:include type="modules" name="footer3" style="footer" />
                <jdoc:include type="modules" name="footer4" style="footer" />
                <jdoc:include type="modules" name="footertext" style="footer" />
            </div>
        </div>
        <jdoc:include type="modules" name="adright" style="rightbanner" />
    </body>
</html>
