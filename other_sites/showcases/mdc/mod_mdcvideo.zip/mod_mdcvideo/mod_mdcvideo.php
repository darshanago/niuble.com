<?php

// no direct access
defined('_JEXEC') or die;

require JModuleHelper::getLayoutPath('mod_mdcvideo', $params->get('layout', 'default'));
