<?php
// no direct access
defined('_JEXEC') or die;
?>
<div class="center playPanel" onclick="$(this).children().show()" style="cursor:pointer">
    <embed style="display:none" src="<?=$params->get('link')?>"
        quality="high" 
        width="382" 
        height="240" 
        align="middle" 
        allowScriptAccess="always" 
        allowFullScreen="true" 
        mode="transparent" 
        type="application/x-shockwave-flash"></embed>
</div>
