<?php

// no direct access
defined('_JEXEC') or die;

require JModuleHelper::getLayoutPath('mod_mdcmod', $params->get('layout', 'default'));
