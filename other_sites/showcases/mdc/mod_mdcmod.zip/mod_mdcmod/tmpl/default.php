<?php
// no direct access
defined('_JEXEC') or die;
?>

<div class="m_waveheader">
    <div class="m_header">
        <h1><?=$module->title?></h1>
    </div>
    <div class="m_body">
        <div class="m_sep_line"></div>
        <div class="m_layout">
            <img class="icon" src="<?=$params->get('icon')?>"/>
            <?=$params->get('content')?>
        </div>
    </div>
    <div class="m_controll clearfix">
        <a href="<?=$params->get('link')?>" class="btn_go_green"><div class="btn_layout clearfix">
                <div class="btn_head"></div><div class="btn_body">
            <?=$params->get('button')?>
            </div><div class="btn_tail"></div></div></a>
    </div>
    <div class="m_bottom"></div>
</div>
