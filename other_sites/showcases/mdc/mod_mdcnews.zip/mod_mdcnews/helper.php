<?php

defined('_JEXEC') or die('Restricted access');

require_once JPATH_SITE.'/components/com_content/helpers/route.php';
jimport('joomla.application.categories');

class modMdcnewsHelper
{
	public static function loadScripts(JRegistry $params, stdClass $module)
	{
		$document = &JFactory::getDocument();
		$document->addScript(JURI::root(true) . '/modules/mod_mdcnews/js/jquery-1.4.4.js');
		$document->addScript(JURI::root(true) . '/modules/mod_mdcnews/js/jquery.tools.min.js');
		$document->addScript(JURI::root(true) . '/modules/mod_mdcnews/js/jquery.user.plugin.js');
		$document->addScript(JURI::root(true) . '/modules/mod_mdcnews/js/main.js');
		$document->addStyleSheet(JURI::root(true) . '/modules/mod_mdcnews/css/autoroll.css');
	}

	public static function getList($params)
	{
        $db = JFactory::getDbo();
		$date = JFactory::getDate();
		$now = $db->Quote($date->toMySQL());
		$nullDate = $db->Quote($db->getNullDate());

        $query = $db->getQuery(true);
        $query->select('id,introtext,publish_up,metadata,title');
        $query->from('#__content');
        $query->where('catid = '.$params->get('category'));
        $query->where('state = 1');
		$query->where('(publish_up = '.$nullDate.' OR publish_up <= '.$now.')');
		$query->where('(publish_down = '.$nullDate.' OR publish_down >= '.$now.')');
        $query->order('ordering, publish_up');

        $db->setQuery($query, 0, $params->get('limit'));
        $items = $db->loadObjectList();

		return $items;
	}
	
}
