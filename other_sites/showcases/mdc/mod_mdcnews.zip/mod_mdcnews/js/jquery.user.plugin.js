// scrollable & overlay gallery
jQuery.fn.scrollOverlay = function(e){
	var OBJ=$(this),OVERLAYBOX=$(e.overlay),screenShots = {
	_OVERLAYBOX : '',
	_LAREGIMG : e.path,
	overlayApi:[],
	scrollerApi:[],
	initGallery : function(){
		var overlayBox = OVERLAYBOX, nextHandler = $('#next',overlayBox),
			prevHandler = $('#prev',overlayBox),imgThumbs = $('img',OBJ);
			// select the overlay element - and "make it an overlay"
			 OVERLAYBOX.overlay({
				// some mask tweaks suitable for facebox-looking dialogs
				mask: {
					// you might also consider a "transparent" color for the mask
					color: '#fff',
					// load mask a little faster
					loadSpeed: 200,
					// very transparent
					opacity: 0.5
				},
				// disable this for modal dialog-type of overlays
				closeOnClick: true,
				onClose : function(){screenShots.scrollerApi.play();}
			});
			screenShots.overlayApi=OVERLAYBOX.data("overlay");
			screenShots._OVERLAYBOX = OVERLAYBOX;
			imgThumbs.live('click',screenShots.doShowOverlay)
			nextHandler.hide().live('click',screenShots.doNextImg);
			prevHandler.hide().live('click',screenShots.doPrevImg);
			
	},
	initScroller : function(){
		var scrollerBox = OBJ;
		scrollerBox.scrollable({circular: true}).autoscroll({ autoplay: true}).navigator({
        // select #flowtabs to be used as navigator
		   navi: ".dot-pagination",

        // select A tags inside the navigator to work as items (not direct children)
        naviItem: 'a',
        // assign "current" class name for the active A tag inside navigator
        activeClass: 'active',

        // make browser's back button work
        history: true

		 });
		screenShots.scrollerApi=scrollerBox.data("scrollable");
	},
	doShowOverlay : function(){
		var handle=$(this),imgNo=parseInt(handle.attr("rel")),imgObj=$('.largeImg',screenShots._OVERLAYBOX);
		screenShots.doSwapImg(imgNo,imgObj);
		screenShots.overlayApi.load();
		screenShots.scrollerApi.stop();
	},
	doNextImg : function(){
			var handle=$(this),imgObj=$('.largeImg',screenShots._OVERLAYBOX),
			imgNo = parseInt(imgObj.attr("rel"))+1;
			screenShots.doSwapImg(imgNo,imgObj);
			},
	doPrevImg : function(){
			var handle=$(this),imgObj=$('.largeImg',screenShots._OVERLAYBOX);
			imgNo = parseInt(imgObj.attr("rel"))-1;
			screenShots.doSwapImg(imgNo,imgObj);
			if(imgNo===1){}
			},
	doSwapImg : function(imgNo,imgObj){
			   var nextHandler = $('#next',OVERLAYBOX),prevHandler = $('#prev',OVERLAYBOX),loader = $('#loader',OVERLAYBOX),
					 imgPath = screenShots._LAREGIMG + imgNo + ".jpg";
			   if(imgNo===1){prevHandler.hide();} else {prevHandler.show();}
			   if(imgNo===20){nextHandler.hide();} else {nextHandler.show();}
			  imgObj.hide();
			  loader.show(); 
				if(imgNo<=20&imgNo>=1){
				//console.debug(imgNo);
				imgObj.attr({
					src:imgPath,
					rel:imgNo
					})
				imgObj.load(function(){imgObj.fadeIn();loader.hide();});
				}else{return;}
			}
}
	screenShots.initScroller();
	screenShots.initGallery();
}