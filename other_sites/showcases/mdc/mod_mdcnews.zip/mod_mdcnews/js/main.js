jQuery(function($) {
	$(document).ready(function(){
	 $(".scrollable").scrollable({circular: true}).autoscroll({ autoplay: true}).navigator({
		navi: ".dot-pagination",
        naviItem: 'a',
        activeClass: 'active',
        history: true
	    });
    });
});
