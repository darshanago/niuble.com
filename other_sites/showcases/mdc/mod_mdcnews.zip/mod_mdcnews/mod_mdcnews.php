<?php
/**
 * RokTwittie Module
 *
 * @package RocketTheme
 * @subpackage roktwittie
 * @version   1.3 June 13, 2011
 * @author    RocketTheme http://www.rockettheme.com
 * @copyright Copyright (C) 2007 - 2011 RocketTheme, LLC
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 */

defined('_JEXEC') or die('Restricted access');
require_once dirname(__FILE__).DS.'helper.php';

jimport('modules.mod_articles_categories.helper');
modMdcnewsHelper::loadScripts($params, $module);

$list = modMdcnewsHelper::getList($params);
if (!empty($list)) {
    require(JModuleHelper::getLayoutPath('mod_mdcnews'));
}
