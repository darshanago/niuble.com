<?php
defined('_JEXEC') or die('Restricted access');
?>
<div class="m_gray">
    <div class="m_header"></div>
    <div class="m_body marquee">
        <h1>News</h1>
        <div class="scrollable">
            <div class="page1 news items clearfix">
            <?php foreach($list as $item):
                if($params->get('show')=='author')
                    $show = $item->author ? $item->author : 'Manager';
                else
                    $show = $item->title;
            ?>
                
                <div>
                    <p><b><?=substr($show, 0, 15)?></b> | <?=date('d.m.Y', strtotime($item->publish_up))?></p>
                    <p><?=substr($item->introtext, 0, 250)?><p>
                </div>
            <?php endforeach;?>
            </div>
        </div>
    </div>
    <div class="m_controll">
        <ul class="dot-pagination">
            <?php foreach($list as $key=>$item):?>
                <li><a href="#thumbs1" id="t<?=$key?>" <?=$key==0 ? 'class="active"' : ''?>><?=$key?></a></li>
            <?php endforeach;?>
        </ul>
    </div>
    <div class="m_tail"></div>
</div>
