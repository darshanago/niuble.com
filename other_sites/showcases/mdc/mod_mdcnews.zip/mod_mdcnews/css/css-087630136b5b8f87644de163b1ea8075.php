<?php 
ob_start ("ob_gzhandler");
header("Content-type: text/css; charset= UTF-8");
header("Cache-Control: must-revalidate");
$expires_time = 1440;
$offset = 60 * $expires_time ;
$ExpStr = "Expires: " . 
gmdate("D, d M Y H:i:s",
time() + $offset) . " GMT";
header($ExpStr);
                ?>

/*** autoroll.css ***/

ul.dot-pagination {text-align:center; width:100%;}ul.dot-pagination li {display:inline-block; width:10px; height:10px; margin:0px 3px;}ul.dot-pagination li a{height:8px;width: 8px;display:block;overflow:hidden;text-indent:1000px;background: url('../images/label.png');}ul.dot-pagination li a.active { background: url('../images/label_active.png'); }.scrollable{width: 210px;height: 176px;overflow: hidden;position: relative;}.scrollable .items{width: 20000em;position: absolute;}.scrollable .items div{width: 210px;float: left;}.m_gray{float:left;width: 240px;}.m_gray .m_header{height: 4px;background: url('../images/gray_white_top.jpg');}.m_gray .m_body{height: 205px;padding: 10px 15px;font-size: 13px;line-height: 150%;color: #666;background: url('../images/gray_white_body.jpg');}.m_gray .m_controll{height: 25px;background: url('../images/gray_white_body.jpg');}.m_gray .m_tail{height: 6px;background: url('../images/gray_white_bottom.jpg');}.m_gray .m_body h1{font-size: 24px;margin-bottom:10px;font-weight: normal;font-family: 'Times New Roman';}